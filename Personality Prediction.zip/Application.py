#!/usr/bin/env python
# coding: utf-8

# In[10]:


import numpy as np
from flask import Flask, render_template,request
from sklearn.preprocessing import StandardScaler
import joblib



# In[11]:


app = Flask(__name__) #Naming the application
model = joblib.load("Personality Prediction Final Model.pkl")
scaler = StandardScaler()


# In[4]:


@app.route('/') # Mapping url to perform specific functions that will handle logic [ root url ]
def home():
    return render_template('index.html') # used to generate output from the default template file


@app.route('/submit', methods=['POST', 'GET'])
def result():
    if request.method == 'POST':
        gender = request.form['gender']
        selectedGender = "Male"
        if gender == "Female":
            gender_no = 1
            selectedGender = "Female"
        else:
            gender_no = 2
        age = float(request.form['age'])  # Convert to float
        openness = float(request.form['openness'])  # Convert to float
        neuroticism = float(request.form['neuroticism'])  # Convert to float
        conscientiousness = float(request.form['conscientiousness'])  # Convert to float
        agreeableness = float(request.form['agreeableness'])  # Convert to float
        extraversion = float(request.form['extraversion'])  # Convert to float
        selectedAge = int(request.form['age'])
        selectedOpen = int(request.form['openness'])
        selectedNeuro = int(request.form['neuroticism'])
        selectedAgree = int(request.form['agreeableness'])
        selectedCons = int(request.form['conscientiousness'])
        selectedExtra = int(request.form['extraversion'])
        
        
        # Apply the same scaling factors used during model training
        # age = (age - mean_age) / std_age
        # openness = (openness - mean_openness) / std_openness
        # neuroticism = (neuroticism - mean_neuroticism) / std_neuroticism
        # conscientiousness = (conscientiousness - mean_conscientiousness) / std_conscientiousness
        # agreeableness = (agreeableness - mean_agreeableness) / std_agreeableness
        # extraversion = (extraversion - mean_extraversion) / std_extraversion
        
        result = np.array([gender_no, age, openness, neuroticism, conscientiousness, agreeableness, extraversion], ndmin=2)
        personality = str(model.predict(result)[0])
        return render_template("submit.html", answer=personality)




# In[6]:


if __name__ ==  '__main__':
    app.run(debug=True)


# In[ ]:


# In post - large amount of data can be sent because data is in body
# In get - limited amount of data can be send because data is in header


# In[6]:


get_ipython().run_line_magic('tb', '')


# In[ ]:




